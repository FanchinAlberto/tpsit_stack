var searchData=
[
  ['removequeue_0',['RemoveQueue',['../_cell___t_p_s_i_t_8cpp.html#a6b1506016f189d843f9c17bd96706867',1,'Cell_TPSIT.cpp']]],
  ['removestack_1',['RemoveStack',['../_cell___t_p_s_i_t_8cpp.html#a0a829b7087c73b15d51f7db99ad2e1e4',1,'Cell_TPSIT.cpp']]]
];
