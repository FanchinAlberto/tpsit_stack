var searchData=
[
  ['value_0',['value',['../structcell.html#ab42b9485cfec529609079431e006efcd',1,'cell']]]
];
